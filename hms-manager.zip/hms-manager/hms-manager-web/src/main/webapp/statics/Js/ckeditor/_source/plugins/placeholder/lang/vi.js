﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang( 'placeholder', 'vi',
{
	placeholder :
	{
		title		: 'Thuộc tính đặt chỗ',
		toolbar		: 'Tạo đặt chỗ',
		text		: 'Văn bản đặt chỗ',
		edit		: 'Chỉnh sửa ',
		textMissing	: 'The placeholder must contain text.' // MISSING
	}
});
