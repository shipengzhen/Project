package com.bdqn.pojo;

public class TbCostsCostsitemKey {
    private Integer itemid;

    private Integer costsid;

    public Integer getItemid() {
        return itemid;
    }

    public void setItemid(Integer itemid) {
        this.itemid = itemid;
    }

    public Integer getCostsid() {
        return costsid;
    }

    public void setCostsid(Integer costsid) {
        this.costsid = costsid;
    }
}